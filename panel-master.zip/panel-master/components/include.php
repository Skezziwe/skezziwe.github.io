<?php
require_once("config.php"); 
$preheader = "./components/preheader.php";
$header = "./components/header.php";
$footer = "./components/footer.php";
?>