<?php

// Domain Name | Format: https://domain.tld
$domain = "https://znix.cc";

// Site Name
$site = "znix.cc";

// Cheat Loader Link
$loader = "xaxa.exe";

// Api key | Format ?username=&pass=&key=
// Do not use same key
$read_api = "key1";
$insert_api = "key2";
$service_api = "key3";

// Footer Credits
$author = "<a href='http://twitter.com/znixhook' target='_blank'>znix</a>";
$twitter = "@znixhook";

// Logo Location | Format: .PNG
$logo = "./assets/img/icon.png";
//Favicon Location
$favicon = "./assets/img/icon.png";
// Website description
$site_desc = "CS:GO Private Cheat";
// Website keywords
$site_keywords = "znix.cc, znixhook, znix, cheat, private cheat, csgo";
?>