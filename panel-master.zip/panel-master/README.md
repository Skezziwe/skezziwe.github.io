# Note
This panel will no longer recieve updates. Please checkout the New Panel.
https://github.com/znixhook/panel-v2
--

# About
Web Panel for your CS:GO cheat.
I tried to make it secure, but if you find any security issue please write in the 'issues' tab.
Only releasing it for the vacban.wtf community <3

Admin acc (change ur pass)
admin:1234567

# Features:
- Auth
  - Login
  - Register(requires invite)
- Dashboard
  - Chatbox
  - Download loader
- Admin Panel
  - Generate invite code
  - Ban/unban user
  - Activate/deactivate sub
  - Rest HWID
  - Promote/demote user from admin
  - Change cheat version
  - Set cheat to detected/undetected
  - Set cheat to under maintainence 
- API
  - login
  - Get user data
  - Get cheat version
  - Get if cheat detected/undetected

# Screenshots
- Dashboard
![](https://codeine.is-inside.me/ZmLkMUS2.png)
- Admin Panel
![](https://codeine.is-inside.me/RWeHQMzn.png)
![](https://codeine.is-inside.me/PIEvwcH2.png)
![](https://codeine.is-inside.me/B6feIdHA.png)
- User list
![](https://codeine.is-inside.me/DLP7E9bx.png)
- Profile
![](https://codeine.is-inside.me/mLoxgalD.png)
